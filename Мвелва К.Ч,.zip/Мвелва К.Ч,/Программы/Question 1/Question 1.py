import numpy as np

# Объявлять параметры
#Начальные условия задачи корректируются таким образом, 
#чтобы сделать матрицу доминирующей по диагонали
Nc = 7
Nr = 13 
epsilon = 1e-3  # Требуемая точность

# Входная матрица A и вектор b
A = np.array([
    [Nc + 5 + 15, 0, Nr, Nr],
    [3, 3 + 14, 0, Nr],
    [2, 5, 3+12, Nc],
    [Nc, Nc + Nr, Nc, 1 +34]
], dtype=float)

b = np.array([2, 2, 2, Nc], dtype=float)

# Проверка доминирование диагонали
def is_diagonally_dominant(A):
    for i in range(len(A)):
        row_sum = np.sum(np.abs(A[i, :])) - np.abs(A[i, i])
        if np.abs(A[i, i]) < row_sum:
            return False
    return True

if not is_diagonally_dominant(A):
    print("Matrix A is not diagonally dominant. Methods may not converge.")
else:
    print("Matrix A is diagonally dominant. Proceeding with iteration methods.")

# Функция для простого итерационного метода
def simple_iteration(A, b, epsilon):
    #Объявление диагональной матрицы
    D = np.diag(np.diag(A)) 
    R = A - D
    #Первоначальное объявление значений
    x = np.zeros_like(b) 
    iteration = 0

    while True:
        x_new = np.dot(np.linalg.inv(D), b - np.dot(R, x))
        iteration += 1
        if np.linalg.norm(x_new - x, ord=np.inf) < epsilon:
            break
        x = x_new

    return x_new, iteration

# Функция для метода Гаусса-Зайделя
def gauss_seidel(A, b, epsilon):
    x = np.zeros_like(b)  # Initial guess
    iteration = 0
    n = len(b)

    while True:
        x_new = np.copy(x)
        for i in range(n):
            s1 = np.dot(A[i, :i], x_new[:i])
            s2 = np.dot(A[i, i+1:], x[i+1:])
            x_new[i] = (b[i] - s1 - s2) / A[i, i]

        iteration += 1
        if np.linalg.norm(x_new - x, ord=np.inf) < epsilon:
            break
        x = x_new

    return x_new, iteration

# Решение с использованием простого итерационного метода
try:
    x_simple, iter_simple = simple_iteration(A, b, epsilon)
    print(f"Simple Iteration Method:\nSolution: {x_simple}\nIterations: {iter_simple}")
except np.linalg.LinAlgError as e:
    print(f"Error in Simple Iteration Method: {e}")

# Решение с использованием метода Гаусса-Зайделя
try:
    x_gauss, iter_gauss = gauss_seidel(A, b, epsilon)
    print(f"Gauss-Seidel Method:\nSolution: {x_gauss}\nIterations: {iter_gauss}")
except np.linalg.LinAlgError as e:
    print(f"Error in Gauss-Seidel Method: {e}")
