from scipy.optimize import bisect, newton, fixed_point
#Вводим уравнений
def first_equation(x):
    Nc = 7
    Nr = 23
    return (x**3 / Nr**3) - (x / Nr) + (x / Nc)

def second_equation(x):
    Nc = 7
    Nr = 23
    return x**3 / (Nc * Nr) + 2 * x - (Nc + Nr)

def third_equation(x):
    Nc = 7
    Nr = 23
    return x**3 / (Nc * Nr) + x / Nc + (Nc * Nr)

def differential_eq3(x):

    Nc = 7
    Nr = 23
    return 3 * x**2 / (Nc * Nr) + 1 / Nc

def fourth_equation(x):

    Nc = 7
    Nr = 23
    return x**3 / (Nr * 1) + x / Nc - (Nc * Nr)
#Построим функции 
#Метод хорда
def chords_method(f, a, b, tol=1e-6):
    #Проверка знаков
    if f(a) * f(b) >= 0:
        raise ValueError("Function must have opposite signs at endpoints.")
    #Сам метод
    while abs(b - a) > tol:
        c = (a * f(b) - b * f(a)) / (f(b) - f(a))
        if f(c) == 0:
            return c
        elif f(a) * f(c) < 0:
            b = c
        else:
            a = c

    return (a + b) / 2

# Решение первого ураавнения с помощью метода bisect
# Конечные точки должны были быть скорректированы в соответствии с теоремой о промежуточном значении, изложенной ранее
root1 = bisect(first_equation, 100, -100)
print("Root of the first equation (bisection method):", root1)

# Решение второго уравнения с использованием метода фиксированной точки SciPy
def g(x):
    Nc = 7
    Nr = 23
    return (30 - x**3 / (Nc * Nr)) / 2

root2 = fixed_point(g, 10)
print("Root of the second equation (fixed-point iteration):", root2)

# Решение второго уравнения с использованием метода Ньютона SciPy
root3 = newton(third_equation, -100, differential_eq3)
print("Root of the third equation (Newton-Raphson method):", root3)

# Решение второго уравнения с использованием метода Хорда
root4 = chords_method(fourth_equation, 7, 23)
print("Root of the fourth equation (Chords method):", root4)