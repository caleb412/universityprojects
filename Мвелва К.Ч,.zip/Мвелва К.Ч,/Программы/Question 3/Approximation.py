import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Ввод данных из таблицы принимая Nc = 23 и Nr = 7
x_data = np.array([-2, -1, 0, 1, 2])
y_data = np.array([23, 7, -1, 7, 23]) 

# Определение графических функциональных структур
#Парабола
def parabola(x, a, b, c):
    return a * x**2 + b * x + c
#Линейная функция
def linear(x, a, b):
    return a * x + b
#Экспонентный
def exponential(x, a, b):
    return a * np.exp(b * x)

# Использование метода SciPy curve_fit
popt_parabola, _ = curve_fit(parabola, x_data, y_data)
popt_linear, _ = curve_fit(linear, x_data, y_data)
popt_exponential, _ = curve_fit(exponential, x_data, y_data)


# Вывод коэффициентов
print("Parabola coefficients:", popt_parabola)
print("Linear coefficients:", popt_linear)
print("Exponential coefficients:", popt_exponential)


# Создание точек для построения графика
x_plot = np.linspace(-2.5, 2.5, 100)
y_parabola_plot = parabola(x_plot, *popt_parabola)
y_linear_plot = linear(x_plot, *popt_linear)
y_exponential_plot = exponential(x_plot, *popt_exponential)


# Построение графика результатов
plt.figure(figsize=(8, 6))
plt.scatter(x_data, y_data, label="Data Points")
plt.plot(x_plot, y_parabola_plot, label="Parabola")
plt.plot(x_plot, y_linear_plot, label="Linear")
plt.plot(x_plot, y_exponential_plot, label="Exponential")

plt.legend()
plt.xlabel("x")
plt.ylabel("y")
plt.title("Least Squares Approximation")
plt.grid(True)
plt.show()