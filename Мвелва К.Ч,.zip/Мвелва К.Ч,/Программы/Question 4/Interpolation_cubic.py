import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

# Ввод параметров
Nr = 23
Nc = 7
N = 4
a = Nc 
b = Nr 

# Определение функции
def f(x):
    return Nr * x + np.sin(x)

# Сгенерируйте значения x (узлы) и соответствующие значения y
x_knots = np.linspace(a, b, N + 1)
y_knots = f(x_knots)

# Выполнение интерполяции кубическим сплайном
spline = CubicSpline(x_knots, y_knots)

# Создание сетки для построения графика
x_fine = np.linspace(a, b, 500)
y_fine = f(x_fine)
y_spline = spline(x_fine)

# Построение графика исходной функции и сплайновой интерполяции
plt.figure(figsize=(10, 6))
plt.plot(x_fine, y_fine, label="Original Function", color="blue")
plt.plot(x_fine, y_spline, label="Cubic Spline", linestyle="--", color="red")
plt.scatter(x_knots, y_knots, color="black", label="Knots")
plt.xlabel("x")
plt.ylabel("f(x)")
plt.title("Cubic Spline Interpolation")
plt.legend()
plt.grid(True)
plt.show()