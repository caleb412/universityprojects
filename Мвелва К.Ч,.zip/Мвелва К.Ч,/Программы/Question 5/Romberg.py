import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import romberg, trapezoid

def f1(x):

    return (x**Nr)* (np.log(x))**Nc

def f2(x, Nr, Nc):

    return ((2 * np.sin(x))**(2*Nr)) * (np.cos(x))**(2*Nc)

# Параметры для f1
a1 = 0.5
b1 = 1.0

# Параметры для f2
Nr = 23
Nc = 7
a2 = 0
b2 = np.pi

# Вычисление интегралов с помощью метода Ромберга
integral1 = romberg(f1, a1, b1)
integral2 = romberg(lambda x: f2(x, Nr, Nc), a2, b2)

# Print the results 
print("Integral 1 (Romberg):", integral1)
print("Integral 2 (Romberg):", integral2)

# --- Trapezoidal Rule for f1

# Установка количества подинтервалов для трапециевидного правила
n1_trap = 100

# Вычисление интеграла с использованием трапециевидного правила
integral1_trap = trapezoid(f1(np.linspace(a1, b1, n1_trap + 1)))

print("Integral 1 (Trapezoidal):", integral1_trap)

# --- Plotting for f1 

# Создание значений x для построения графика
x_fine1 = np.linspace(a1, b1, 100)
y_fine1 = f1(x_fine1)

# Построение функции
plt.figure(figsize=(8, 4))
plt.plot(x_fine1, y_fine1, label='Function')
plt.xlabel('x')
plt.ylabel('f1(x)')
plt.title('Trapezoidal Rule for f1(x)')
plt.legend()
plt.grid(True)
plt.show()

# --- Plotting for f2 

# Создание значений x для построения графика
x_fine2 = np.linspace(a2, b2, 100)
y_fine2 = f2(x_fine2, Nr, Nc)

# Построение функции
plt.figure(figsize=(8, 4))
plt.plot(x_fine2, y_fine2, label='Function')
plt.xlabel('x')
plt.ylabel('f2(x)')
plt.title('Romberg Integration for f2(x)')
plt.legend()
plt.grid(True)
plt.show()