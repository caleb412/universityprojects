import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import simpson

def f(x, Nr, Nc):
    """
    Calculates the value of the function for given x, Nr, and Nc.

    Args:
        x: The value of x.
        Nr: The value of Nr.
        Nc: The value of Nc.

    Returns:
        The value of the function at x.
    """
    return (2 * np.sin(x))**(2*Nr) * (np.cos(x))**(2*Nc)

# Set the parameters
Nr = 23
Nc = 7
a = 0
b = np.pi
n = 20  # Number of subintervals (must be even for Simpson's rule)

# Generate x-values
x = np.linspace(a, b, n + 1)

# Calculate y-values
y = f(x, Nr, Nc)

# Calculate the integral using Simpson's rule
integral = simpson(y)

# Create x-values for plotting the function
x_fine = np.linspace(a, b, 100)
y_fine = f(x_fine, Nr, Nc)

# Plot the function
plt.figure(figsize=(10, 6))
plt.plot(x_fine, y_fine, label='Function')

# Set plot labels and title
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Simpson\'s Rule Integration')
plt.legend()
plt.grid(True)

# Display the integral value on the plot
plt.text(0.8, 0.1, f"Integral: {integral:.4f}", transform=plt.gca().transAxes)

# Show the plot
plt.show()

print("Integral:", integral)