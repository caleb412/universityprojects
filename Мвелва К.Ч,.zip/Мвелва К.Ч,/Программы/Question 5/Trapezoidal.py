import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import trapezoid
# Определение функциональной структуры
def f(x, Nr, Nc):

    return (x**Nr) * (np.log(x))**Nc

# Определение переменных и параметров
Nr = 23
Nc = 7
a = 0.5
b = 1
delta_x = 0.1

# Вычислите количество подинтервалов
n = 11

# Генерирование значений x
x = np.linspace(a, b, n + 1)

# Генерирование значений y
y = f(x, Nr, Nc)

# Вычисление интеграла по правилу трапеции
integral = trapezoid(y, x)

# Вычисление вершин трапеции для построения графика
x_trapezoid = np.array([[x[i], x[i], x[i + 1], x[i + 1]] for i in range(n)]).flatten()
y_trapezoid = np.array([[0, y[i], y[i + 1], 0] for i in range(n)]).flatten()

#Создание значений x для построения графика функции
x_fine = np.linspace(a, b, 100)
y_fine = f(x_fine, Nr, Nc)

# Построение графика функции и трапеций
plt.figure(figsize=(10, 6))
plt.plot(x_fine, y_fine, label='Function')
plt.fill(x_trapezoid, y_trapezoid, color='lightgray', alpha=0.5, label='Trapezoids')
plt.plot(x_trapezoid, y_trapezoid, color='gray')  # Plot the trapezoid outlines

# Установка меток
plt.xlabel('x')
plt.ylabel('f(x)')
plt.title('Trapezoidal Rule Integration')
plt.legend()
plt.grid(True)

# Отображение интегрального значения
plt.text(0.8, 0.1, f"Integral: {integral:.4f}", transform=plt.gca().transAxes)

# Show the plot
plt.show()
print ("Integral:", integral) 