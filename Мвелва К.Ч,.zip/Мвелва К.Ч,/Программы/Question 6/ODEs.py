import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
Nc = 23
Nr = 7
a = np.sqrt(Nc)
b = Nr
def ode_func(t, y):
    y, y_prime = y
    return [y_prime, a * t - y]

# Начальные условия
t_span = [0, np.pi]  # Мы программируем переменную x как время t
y0 = [0, a + b]  #Начальные условия y и y'

# Решение ODE с использованием функции solve_ivp в SciPy (RK45)
sol_rk45 = solve_ivp(ode_func, t_span, y0, method='RK45')

# Решение ODE с использованием метода Эйлера (с использованием dsolve_ivp с использованием метода 'RK 23')
sol_euler = solve_ivp(ode_func, t_span, y0, method='RK23', dense_output=True) 

# Генерирование четных точек для метода Эйлера
t_euler = np.linspace(t_span[0], t_span[1], 10)  # Количество точек 
y_euler = sol_euler.sol(t_euler)[0]

# Результаты
t_rk45 = sol_rk45.t
y_rk45 = sol_rk45.y[0]

# Построение графика
plt.figure()
plt.plot(t_rk45, y_rk45, label='Runge-Kutta (RK45)')
plt.plot(t_euler, y_euler, label='Euler')
plt.xlabel('Time (t)')
plt.ylabel('y(t)')
plt.legend()
plt.title('Runge-Kutta and Euler Methods')
plt.grid(True)
plt.show()
